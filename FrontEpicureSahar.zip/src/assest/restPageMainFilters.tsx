import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux/es/exports";
import { bindActionCreators } from "redux";
import { actionCreator } from "../state";
import { FilterElement, FilterElements, FilterElementText } from "../Style/RestaurantsPageStyle";

const RestPageAssest=() =>{
    const dispatch =useDispatch() ;
    const firstButton = useRef<HTMLButtonElement>(null);
    const [focus,setFocus]=useState(true)
    useEffect(()=>{
        const a=document.getElementById("RestPageContainer");
        if(a) {
            a.style.visibility='visible'; 
        }
        if(firstButton.current){
            firstButton.current.style.fontWeight="bold";
            firstButton.current.style.borderBottom= "1.8px solid rgba(222, 146, 0, 0.9)";
        }

    },[focus]);

    const {filterRestaurant} =bindActionCreators(actionCreator,dispatch)
    const HandelClick=()=>{
        if(firstButton.current){
            firstButton.current.style.fontWeight="200";
            firstButton.current.style.borderBottom= "none";
        }
    
    }

    return(
        <FilterElements>
            <FilterElement>
                <FilterElementText  ref={firstButton} onClick={() =>{filterRestaurant("All");setFocus(!focus);}}>All</FilterElementText>
                <FilterElementText onClick={() =>{filterRestaurant("New"); HandelClick()}}>New</FilterElementText>
                <FilterElementText onClick={() =>{filterRestaurant("Most Popular");HandelClick();}}>Most Popular</FilterElementText>
                <FilterElementText  onClick={() =>{filterRestaurant("Open Now");HandelClick();}}>Open Now</FilterElementText>
                <FilterElementText  onClick={() =>{filterRestaurant("Map");HandelClick(); }}>Map View</FilterElementText>
            </FilterElement>
        </FilterElements>
    )
}


export default RestPageAssest;