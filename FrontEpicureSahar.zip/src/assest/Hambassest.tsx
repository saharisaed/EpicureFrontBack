import { useState } from "react";
import Hamburger from '../components/Hamburger'
import { ReactComponent as Hamb } from '../Media/Icons/Hamburger_icon.svg'
import { ReactComponent as Hide} from '../Media/Icons/close_icon.svg'
import { CloseIcon, Hambelements, HambStyle, HideMenuIcon, MenuIcon, ShowMenuIcon } from "../Style/HamburgerStyle";

const NavbarAssest = () =>{
    const [showhambmenu, setshowhambmenu] = useState(false)
    const [showclose,setshowclose]= useState(false)
    const [hidehambic,sethidehambic]= useState(false)
    const [visib,setvisib]= useState(true)
    const width=document.documentElement.clientWidth;
    const handleShowNavbar = () => {
      setshowhambmenu(!showhambmenu)
      setshowclose(!showclose)
      sethidehambic(hidehambic)
      setvisib(!visib);
      const c=document.getElementById('Cartelement');
      if(c) c.style.visibility='hidden';
      let a=document.getElementById('Navbar');
      if(a){
          if(visib&&width<796) a.style.visibility='hidden';
        else a.style.visibility='visible';
      }
    }
  
  return(
      <HambStyle id="HambStyle">
        <MenuIcon onClick={handleShowNavbar} >
          {(showclose && !hidehambic) ?
          (
            <HideMenuIcon>
              <Hamb/>  
            </HideMenuIcon>
          ):(
            <ShowMenuIcon>
              <Hamb/>  
            </ShowMenuIcon>
          )}
        </MenuIcon>
        
        <CloseIcon id="CloseIcon" onClick={handleShowNavbar} >
          {(showclose && !hidehambic)?<CloseIcon>
            <Hide/>
          </CloseIcon>:null}
        </CloseIcon> 

        {showhambmenu ?<Hambelements id="Hambelements">        
            <Hamburger/>
        </Hambelements>:null}
    </HambStyle>
  )
}



export default NavbarAssest