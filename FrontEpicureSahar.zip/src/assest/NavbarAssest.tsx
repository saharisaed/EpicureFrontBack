import { Icon, Navbarelements } from "../Style/NavbarStyle";
import CartAssest from "./Cartassest";
import SearchAssest from "./searchAssest";

const Assest=() =>{

    return(
        <Icon>
        {  
        <Navbarelements>
          <SearchAssest/>
          <Icon><img src={require('../Media/Icons/person_icon.png')} alt={"login icon"} /></Icon>
          <CartAssest/>
        </Navbarelements>
        } 
        
      </Icon>
      
    )

}









export default Assest