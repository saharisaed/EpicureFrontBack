import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setDishs } from "../state/reducer/AllDishs";


const GetAllDishs=()=>{
    const dispatch=useDispatch();
 useEffect(()=>{
    const fetchDishs=async()=>{
      const response2=await fetch("http://localhost:3001/api/dishs/getDishs").then(
        (data)=> {
  
          return data.json();
        }
      )
      dispatch(setDishs(response2));
    }

   
      fetchDishs();
    },[])
}

export default GetAllDishs