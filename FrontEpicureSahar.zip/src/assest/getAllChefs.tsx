import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setChefs } from "../state/reducer/AllChefs";


const GetAllChefs=()=>{
    const dispatch=useDispatch();
   useEffect(()=>{ 
    const fetchChefs=async()=>{
      const response2=await fetch("http://localhost:3001/api/chefs/getChefs").then(
        (data)=> {
  
          return data.json();
        }
      )
      dispatch(setChefs(response2));
    }
 
      fetchChefs();
    },[])
}

export default GetAllChefs;