import { useEffect, useState } from "react";
import { ReactComponent as Hide} from '../Media/Icons/close_icon.svg'
import Search from "../PopUps/search";
import { Closeicon, SearchAssestStyle, SearchDesktopelements, Searchelements, SearchIcon, SearchTitle } from "../Style/SearchStyle";

const SearchAssest=()=>{
    const [showsearch, setshowsearch] = useState(false);
    const [showclose,setshowclose]= useState(false)
    const [visib,setvisib]= useState(true);
    const [width,setWidth]=useState(document.documentElement.clientWidth);
    const resizeHandler=()=>{
      setWidth(window.innerWidth)
    }
    useEffect(() => {
      window.addEventListener("resize",resizeHandler)
    },[]);
    
    const handleshowsearch = () => {
      setshowsearch(!showsearch);
      setshowclose(!showclose)
      setvisib(!visib);
      const b=document.getElementById('searchICN');
      const c=document.getElementById('Cartelement');
      if(c) c.style.visibility='hidden';
      if(b){
        if(!visib){
          b.style.visibility='hidden';
        }
        if(visib){
          b.style.visibility='visible';
        }
      }
  }
        return(
            <SearchAssestStyle id="SearchAssestStyle">    
                <SearchIcon>
                    <img src={require('../Media/Icons/search_icon.png')} onClick={handleshowsearch} alt={"search icon"}/>
                </SearchIcon>    
            
                {showsearch && width<796 ? <Searchelements id="Searchelements">    
                    <Closeicon id="searchcloseicon"  onClick={handleshowsearch} >
                      {showclose ?<Closeicon>
                       <Hide/>
                      </Closeicon>:null}
                   </Closeicon>    
                    <SearchTitle> 
                        Search
                    </SearchTitle>
                        <Search/>
                </Searchelements>:null}
                 {showsearch && width>796 ? <SearchDesktopelements id="SearchDesktopelements">    
                        <Search/>
                </SearchDesktopelements>:null}
            </SearchAssestStyle> 
        )


}

export default SearchAssest