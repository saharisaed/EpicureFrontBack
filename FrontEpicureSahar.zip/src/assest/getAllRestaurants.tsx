import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setRestaurants } from "../state/reducer/AllRestaurants";


const GetAllRestaurants=()=>{
    const dispatch=useDispatch();
 
 useEffect(()=>{
    const fetchRestaurants=async()=>{
      const response2=await fetch("http://localhost:3001/api/restaurants/getRestaurants").then(
        (data)=> {
  
          return data.json();
        }
      )
      dispatch(setRestaurants(response2));
    }

   
      fetchRestaurants();
    },[])
}

export default GetAllRestaurants