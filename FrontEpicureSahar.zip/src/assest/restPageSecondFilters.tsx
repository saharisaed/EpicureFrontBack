import { useState } from "react";
import Distance from "../components/Distance";
import PriceRange from "../components/PriceRange";
import RatingFilter from "../components/RatingFilter";
import { DownArrow, Filter, FilterContainer, FilterText } from "../Style/RestaurantsPageStyle";

const RestPageSecondFilters=() =>{
    const[PriceRangeOn,setPriceRangeOn]=useState(false);
    const[DistanceRangeOn,setDistanceRangeOn]=useState(false);
    const[RateFilterOn,setRateFilterOn]=useState(false);
 
    return(
            <Filter>
                <FilterContainer>
                    <FilterText>Price Range</FilterText>
                    <DownArrow onClick={()=>{setPriceRangeOn(!PriceRangeOn);setDistanceRangeOn(false);setRateFilterOn(false)}}/> 
                </FilterContainer>
                {PriceRangeOn&&<PriceRange/>}

                <FilterContainer>
                    <FilterText >Distance</FilterText>
                    <DownArrow onClick={()=>{setDistanceRangeOn(!DistanceRangeOn);setPriceRangeOn(false);setRateFilterOn(false)}}/> 
                </FilterContainer>
                {DistanceRangeOn&&<Distance/>}

                <FilterContainer>
                    <FilterText>Rating</FilterText>
                    <DownArrow onClick={()=>{setDistanceRangeOn(false);setPriceRangeOn(false);setRateFilterOn(!RateFilterOn)}}/> 
                </FilterContainer>
                {RateFilterOn&&<RatingFilter/>}
            </Filter>
       
       
    )
}


export default RestPageSecondFilters;