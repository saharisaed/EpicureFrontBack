import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface RatingList{
  ratingList:boolean[]
}

const initialState: RatingList={
    ratingList:[false,false,false,false,false],
}

export const ratingListSlice=createSlice({
  name:'ratingList',
  initialState,
  reducers:{
    updateList:(state,action:PayloadAction<boolean[]>)=>{
        state.ratingList[0]=action.payload[0];
        state.ratingList[1]=action.payload[1];
        state.ratingList[2]=action.payload[2];
        state.ratingList[3]=action.payload[3];
        state.ratingList[4]=action.payload[4];
    }

    
  }

  
  
})

export const {updateList}=ratingListSlice.actions




