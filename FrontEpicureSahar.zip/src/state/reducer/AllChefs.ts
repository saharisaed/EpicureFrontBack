import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface ChefList{
  chefsList:any[]
}

const initialState: ChefList={
    chefsList:[],
}

export const allChefsSlice=createSlice({
  name:'getChefs',
  initialState,
  reducers:{
    setChefs:(state,action:PayloadAction<any[]>)=>{
      state.chefsList=action.payload;
    }
  } 
})

export const {setChefs}=allChefsSlice.actions
