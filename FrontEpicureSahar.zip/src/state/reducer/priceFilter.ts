import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface PriceRange{
  min:number,
  max:number,

}

const initialState: PriceRange={
    min:12,
    max:375,
}

export const priceFilter=createSlice({
  name:'setPriceRange',
  initialState,
  reducers:{
    setPriceRange:(state,action:PayloadAction<PriceRange>)=>{
      state.min=action.payload.min;
      state.max=action.payload.max;

      
    }

    
  }

  
  
})

export const {setPriceRange}=priceFilter.actions




