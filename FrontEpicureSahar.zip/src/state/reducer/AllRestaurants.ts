import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface RestaurantList{
  restaurantsList:any[]
}

const initialState: RestaurantList={
    restaurantsList:[],
}

export const allRestaurantsSlice=createSlice({
  name:'getRestaurants',
  initialState,
  reducers:{
    setRestaurants:(state,action:PayloadAction<any[]>)=>{
      state.restaurantsList=action.payload;
    }    
}

  
})

export const {setRestaurants}=allRestaurantsSlice.actions
