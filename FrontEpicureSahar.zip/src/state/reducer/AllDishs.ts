import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface DishsList{
  dishsList:any[]
}

const initialState: DishsList={
    dishsList:[],
}

export const allDishsSlice=createSlice({
  name:'getdishs',
  initialState,
  reducers:{
    setDishs:(state,action:PayloadAction<any[]>)=>{
      state.dishsList=action.payload;
    }
  }
})

export const {setDishs}=allDishsSlice.actions
