import { ActionSearch} from "../actions/index"
import { ActionType } from "../action-types";
const initialState ="";

const reducer =(state:string=initialState ,action:ActionSearch) => {
  switch(action.type){
    case ActionType.SEARCH:
        return action.payload;
      
    default:
      return state
  }

}

export default reducer;




