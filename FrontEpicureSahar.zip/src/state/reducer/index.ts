import { combineReducers } from "redux";
import restaurantsReducer from "../reducer/filterRestaurants"
import secondrestaurantsReducer from "../reducer/secondFilter"
import searchReducer from "../reducer/searchSlider"
import { allChefsSlice } from "./AllChefs";
import { allDishsSlice } from "./AllDishs";
import { allRestaurantsSlice } from "./AllRestaurants";
import { priceFilter } from "./priceFilter";

const reducers = combineReducers({
    filter:restaurantsReducer,
    secondfilter:secondrestaurantsReducer,
    search:searchReducer,
    allRestaurants:allRestaurantsSlice.reducer,
    allDishs:allDishsSlice.reducer,
    allChefs:allChefsSlice.reducer,
    priceFilter:priceFilter.reducer,
})

export default reducers;

export type State = ReturnType<typeof reducers>