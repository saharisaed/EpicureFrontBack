import { createSlice } from "@reduxjs/toolkit";
import { PayloadAction } from "@reduxjs/toolkit/dist/createAction";

interface Disatnce{
  distance:number
}

const initialState: Disatnce={
    distance:0,
}

export const distanceRestaurant=createSlice({
  name:'setDistance',
  initialState,
  reducers:{
    setDistance:(state,action:PayloadAction<number>)=>{
      state.distance=action.payload;
      
    }

    
  }

  
  
})

export const {setDistance}=distanceRestaurant.actions




