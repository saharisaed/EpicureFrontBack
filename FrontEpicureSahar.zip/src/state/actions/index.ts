import { ActionType } from "../action-types";


// Define a type for the slice state
interface FilterAction {
    type: ActionType.FILTER
    payload :string
}
interface FilterActionSearch {
    type: ActionType.SEARCH
    payload :string
}


export type ActionSearch=FilterActionSearch;
export type Action =FilterAction;
  
   