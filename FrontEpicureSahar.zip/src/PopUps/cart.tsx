import { Cartcontent, Cartimg, CartStyle, OrderHistory } from "../Style/CartStyle";

const Cart= () =>{
  
    return(
    
            <CartStyle id="CartStyle"> 
                
                <Cartimg src={require('../Media/Icons/cart_icon2.png')} />
                   <Cartcontent>  Your bag is<br></br> empty </Cartcontent>
    
                <OrderHistory >Order history</OrderHistory>
            </CartStyle>    

    )
}

export default Cart;