import { useEffect, useState } from 'react';
import { SearchElement, SearchElements, SearchInput, SearchStyle } from '../Style/SearchStyle';
import SearchInputPopup from './searchInput';
import { bindActionCreators } from 'redux';
import { useDispatch } from 'react-redux';
import { actionCreator } from '../state';

const Search= () =>{
    const dispatch =useDispatch() ;
    const [InputText, setInputText] = useState<string>("");
    const [openHistory,setOpenHistory] = useState(false);
    const {filterSearch} =bindActionCreators(actionCreator,dispatch)
    function To_LowerCase(input_text:any) {
        const  lowerCase = input_text.target.value.toLowerCase();
        return lowerCase;
    
    }

    useEffect(() => {
        filterSearch(InputText);
        (InputText==="")?setOpenHistory(false):setOpenHistory(true);
       
      },[InputText,filterSearch]);

      
    let inputHandler = (input :any) => {
        const searchkey:string =To_LowerCase(input)
        setInputText(searchkey);
    };

    
    return(
        <SearchStyle id="SearchStyle">
            <SearchElements>
                <SearchElement>
                    <img src={require('../Media/Icons/search_icon2.png')} alt={"search icon"}/>
                    <SearchInput type="text" id="name" placeholder='Search for restaurant cuisine, chef' onChange={inputHandler}  ></SearchInput> 
                </SearchElement>
            </SearchElements>
            {openHistory && <SearchInputPopup/>}
        </SearchStyle>    
    )

}
export default Search;