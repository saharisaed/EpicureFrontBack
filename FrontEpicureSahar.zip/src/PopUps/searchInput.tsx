import { SearchPopup, SearchText, SearchTextElemnt } from "../Style/SearchStyle";
import {  useSelector } from "react-redux";
import { State } from "../state";
import { useEffect, useState } from "react";

export interface ListByName{
    name:string;
}

const SearchInputPopup= () =>{
    const searchInput =useSelector((state :State) => state.search)
    const restaurantsAll=useSelector((state :State) => state.allRestaurants);
    const dishsAll=useSelector((state :State) => state.allDishs);
    const [dishSuggistion,setDishSuggistion] =useState<string|undefined>("");
    const [RestaurantSuggistion,setRestaurantSuggistion] =useState<string|undefined>();
    
    useEffect(() => {
        const GetSearchingSuggestion=()=>{
            const restaurantListFilterd=restaurantsAll.restaurantsList.filter((elemnt:ListByName)  => elemnt.name.toLowerCase().includes(searchInput)).shift();
            restaurantListFilterd? setRestaurantSuggistion(restaurantListFilterd.name):setRestaurantSuggistion("");
            const dishesListFilterd=dishsAll.dishsList.filter((elemnt:ListByName)  =>  elemnt.name.toLowerCase().includes(searchInput)).shift();
            dishesListFilterd? setDishSuggistion(dishesListFilterd.name):setDishSuggistion("");   
        }
        GetSearchingSuggestion();
      },[searchInput,dishsAll.dishsList,restaurantsAll.restaurantsList]);

        return(
            <SearchPopup id="searchInput">
                <SearchText>Restaurants:</SearchText>
                <SearchTextElemnt>{RestaurantSuggistion}</SearchTextElemnt>
                <SearchText>Cusine:</SearchText>
                <SearchTextElemnt>{dishSuggistion}</SearchTextElemnt>
            </SearchPopup>
        )
}



export default SearchInputPopup;

