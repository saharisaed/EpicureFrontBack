import RestPageContainer from '../components/RestaurantsPage/ResPageContainer'
import {  ResPageStyle } from '../Style/RestaurantsPageStyle'


const Restaurants = () => { 
  return (
    <ResPageStyle>
      <RestPageContainer/>
    </ResPageStyle>
  )
}

export default Restaurants