import styled from "styled-components";

export const DishIcon=styled.div``
export const Ingredients=styled.div``
export const Price=styled.div`
                            left: 3%;
                            gap: 2px;
                            position: relative;
                            display: flex;
                            align-items: flex-end;`

export const Priceimg=styled.img`
                            padding-bottom: 9%;`

export const DishsContainer=styled.div`
                            width: 100%;`

export const DishContainerText=styled.div`
                            align-content: baseline;
                            height: 24px;
                            padding-left: 20px;
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 24px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;
                            @media only screen and (min-width: 796px){  
                                display:flex;
                                justify-content: center; 
                                font-size: 30px;
                            }`

export const Dishs=styled.div`
                            display: flex;
                            -webkit-flex-direction: row;
                            -ms-flex-direction: row;
                            flex-direction: row;
                            -webkit-align-items: flex-start;
                            -webkit-box-align: flex-start;
                            -ms-flex-align: flex-start;
                            align-items: stretch;
                            padding: 0px;
                            gap: 24px;
                            padding-left: 20px;
                            padding-top: 15px;
                            width: auto;
                            height: 40%;
                            overflow-x: scroll;
                            @media only screen and (min-width: 796px){  
                                justify-content: center;
                                overflow-x: hidden;
                                height: 416px;
                                display: flex;
                            }`