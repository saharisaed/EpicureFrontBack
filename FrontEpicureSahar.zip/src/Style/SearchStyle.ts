import styled from "styled-components";
export const SearchStyle=styled.div`
                                    height: 46px;
                                    display: flex;
                                    align-self: center;
                                    flex-direction: column;
                                   `

export const SearchElements=styled.ul`
                                    height: 0px;
                                    margin-block-end: 15px;
                                    background: none;
                                    list-style: none;
                                    padding: 0px 0px 0px 0px;
                                    display: flex;
                                    background: rgba(255, 255, 255, 0.88);
                                    flex-direction: column;
                                    align-content: space-around;
                                    flex-wrap: wrap;
                                    justify-content: center;
                                    @media only screen and (min-width: 796px){
                                        display:flex;
                                        flex-direction: row;
                                        gap:32px;
                                        padding:0;
                                        
                                    }`

export const SearchElement=styled.li`
                                    background: none;
                                    list-style: none;
                                    text-align: center;
                                    justify-content: center;
                                    box-sizing: border-box;
                                    display: flex;
                                    flex-direction: row;
                                    align-items: center;
                                    padding: 6px 12px;
                                    gap: 8px;
                                    height: 30px;
                                    width: 112%;
                                    border: 0.5px solid #000000;
                                    border-radius: 4px;
                                    @media only screen and (min-width: 796px){
                                        list-style-type: none;
                                    }`     
                                    
export const SearchDesktopelements=styled.li`
                                    @media only screen and (min-width: 796px){
                                        display:flex;
                                        height:auto;
                                        padding-top:15px;
                                    }`  

export const SearchInput=styled.input`
                                    background: none;
                                    width: 220px;
                                    height: 15px;
                                    border-style: hidden;
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 200;
                                    font-size: 12px;
                                    line-height: 15px;
                                    letter-spacing: 1.29px;
                                    color: #000000;
                                    flex: none;
                                    order: 2;
                                    flex-grow: 1;
                                    :focus{
                                        outline: none;
                                        ::placeholder {
                                            opacity: 0.2;
                                        }
                                    }`   

export const SearchAssestStyle=styled.div`
                                        @media only screen and (min-width: 796px){
                                        display: flex;
                                        gap: 15px;
                                        flex-direction: row-reverse;
                                        align-items: center;
                                        }`

export const SearchIcon=styled.div``

export const Closeicon=styled.div`
                                    visibility: visible;
                                    display: flex;
                                    padding-top: 7px;
                                    padding-left: 4px;`

export const Searchelements=styled.div`
                                    position: absolute;
                                    justify-content: flex-start;
                                    left: 0; 
                                    top: 60px;
                                    background-color: #ffffff;
                                    width: 0px;
                                    height: calc(100vh - 60px);
                                    visibility: visible;
                                    display: flex;
                                    flex-direction: column;
                                    align-items: flex-start;
                                    gap: 36px;
                                    top: 0;
                                    width: 105%;
                                    height: 298px;
                                    background: #FFFFFF;
                                    box-shadow: 2px 4px 10px rgb(175 175 175 / 25%);
                                    overflow:hidden;
                                    @media only screen and (min-width: 796px){
                                        display:flex;
                                        flex-direction: row;
                                        gap:32px;
                                        padding:0;
                                    }`

export const SearchTitle=styled.div`
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 200;
                                    font-size: 18px;
                                    line-height: 22px;
                                    letter-spacing: 1.92px;
                                    color: #000000;
                                    align-self: center;
                                    top: 0;
                                    position: absolute;
                                    padding-top: 16px;`


export const SearchPopup=styled.div`
                                    margin-inline-start: -15px;
                                    z-index: 1;
                                    width: 105%;
                                    display: flex;
                                    background-color: white;
                                    height: 138px;
                                    display: flex;
                                    padding: 16px 0px 16px 16px;
                                    flex-direction: column;
                                    align-items: flex-start;
                                    gap: 10px;`

export const SearchText=styled.div`
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 200;
                                    font-size: 16px;
                                    line-height: 19px;
                                    letter-spacing: 1.29px;
                                    color: #000000;
                                    flex: none;
                                    order: 0;
                                    flex-grow: 0;`

export const SearchTextElemnt=styled.div`
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 400;
                                    font-size: 16px;
                                    display: contents;
                                    line-height: 19px;
                                    letter-spacing: 1.29px;
                                    color: #000000;
                                    flex: none;
                                    order: 1;
                                    flex-grow: 0;`