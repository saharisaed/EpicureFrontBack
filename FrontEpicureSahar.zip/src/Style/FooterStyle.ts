import { NavLink } from "react-router-dom";
import styled from "styled-components";

export const FooterStyle=styled.div`
                            display: flex;
                            flex-direction: column;
                            gap: 32px;
                            width: auto;
                            padding-top: 20px;
                            background: #FAFAFA;
                            padding-left: 20px;
                            @media only screen and (min-width: 796px){
                                display: grid;
                                width: -webkit-fill-available;
                                padding-left:145px;
                                align-items: center;
                            }`

export const Footerimg=styled.img`
                            display: flex;
                            justify-content: flex-start;
                            width: fit-content;`

export const Footerimges=styled.div`
                            gap: 15px;
                            display: grid;
                            @media only screen and (min-width: 796px){
                                    grid-row: 3;
                                    display: flex;
                                    padding-bottom:15px;
                            }`
export const Footerlogoimg=styled.img`
                            display: flex;
                            justify-content: flex-start;
                            width: fit-content;
                            @media only screen and (min-width: 796px){
                                grid-row: 2;
                                grid-column: 2;
                                width: 50%;
                                max-width: -webkit-fill-available;
                            }`

export const Footertitle=styled.div`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 35px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;
                            @media only screen and (min-width: 796px){
                                grid-row:1;
                                font-size: 30px;
                                
                            }`

export const Footercontent=styled.div`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 28px;
                            letter-spacing: 2.14px;
                            color: #000000;
                            @media only screen and (min-width: 796px){
                                grid-row:2;
                                font-size: 30px;
                                width: 569px;
                                line-height: 30px;
                            }`


export const Mutalfooter=styled.ul`
                            display: flex;
                            flex-direction: column;
                            align-items: flex-start;
                            gap: 24px;
                            flex: content;
                            background: #FFFFFF;
                            padding-inline-start: 0px;
                            padding-left: 20px;
                            
                            padding-top: 15px;
                            @media only screen and (min-width: 796px){
                                flex-direction: row;
                                justify-content: center;
                            }`


export const MutalfooterLink=styled(NavLink)`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 22px;
                            letter-spacing: 1.92px;
                            color: #000000;
                            text-decoration: none;`