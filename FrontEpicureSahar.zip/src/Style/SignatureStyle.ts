import styled from "styled-components";

export const Signaturediv=styled.div`
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;
                            gap: 32px;
                            width: 100%;
                            background: #FAFAFA;
                            @media only screen and (min-width: 796px){  
                                height: 265px;
                                gap:0px;
                                display: grid;
                                justify-items: center;
                            }`

export const Title=styled.h1`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 35px;
                            padding-top: 24px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;
                            @media only screen and (min-width: 796px){  
                                display:none; 
                            }`

                            
export const DesktopTitle=styled.h1`
                            display:none;
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 30px;
                            line-height: 35px;
                            text-align: center;
                            letter-spacing: 2.14px;
                            text-transform: uppercase;
                            color: #000000;
                            @media only screen and (min-width: 796px){
                                display:grid;
                                visibility: visible; 
                                grid-column: 1 / span 3;
                                grid-row:1;
                                grid-row-end: 1;     
                            }`

export const DishType=styled.h2`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 30px;
                            text-align: center;
                            letter-spacing: 1.97px;
                            color: #000000;
                            @media only screen and (min-width: 796px){  
                                grid-row:  3;
                            }`

export const Signatureimgs=styled.img`
                            @media only screen and (min-width: 796px){  
                                grid-row: 2;
                            }`

                            