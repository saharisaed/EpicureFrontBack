import styled from "styled-components";

export const CartStyle=styled.div`
                            height: 46px;
                            display: flex;
                            background-color: #ffffff;
                            padding-top: 12%;
                            align-content: center;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;
                            @media only screen and (min-width: 796px){
                                display: flex;
                            }`

export const Cartimg=styled.img`
                            padding-top: 95%;
                            @media only screen and (min-width: 796px){
                                padding:0;
                            }`

export const Cartcontent=styled.h1`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 16px;
                            line-height: 20px;
                            text-align: center;
                            letter-spacing: 1.97px;
                            text-transform: uppercase;
                            color: #000000;
                            flex: none;
                            order: 0;
                            flex-grow: 0;
                            top: 22px;
                            display: flex;
                            flex-direction: column;
                            justify-content: flex-start;
                            align-items: center;
                            padding: 0px;
                            gap: 20px;
                            width: 263%;
                            height: 150%;
                            @media only screen and (min-width: 796px){
                                width: fit-content;
                                padding-bottom: 50px;
                            }`
                        
export const Cartassest=styled.div``

export const Carticon=styled.div`
                            @media only screen and (min-width: 796px){
                                padding-right: 45px;
                            }`

export const Cartelement=styled.div`
                            visibility: visible;
                            display: flex;
                            position: fixed;
                            z-index: 2;
                            flex-direction: column;
                            gap: 24px;
                            left: 0px;
                            width: 100%;
                            height: 218px;
                            background: #FFFFFF;
                            box-shadow: 2px 4px 10px rgb(175 175 175 / 25%);
                            align-content: center;
                            align-items: center;
                            justify-content: space-between;
                            overflow:hidden;
                            @media only screen and (min-width: 796px){
                                width: 497px;
                                left: 67%;
                                margin-top: 10px;
                                height: 500px;
                                justify-content: center;
                                align-items: center;
                            }`

export const OrderHistory = styled.button`
                                display:none;
                                background-color: white;
                                color: black;
                                border: 1px solid #000000;
                                width: 206px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 400;
                                font-size: 18px;
                                line-height: 20px;
                                text-align: center;
                                letter-spacing: 2.67px;
                                text-transform: uppercase;
                                color: #000000;
                                @media only screen and (min-width: 796px){
                                    display:flex;
                                    justify-content: center;
                                }`