import styled from "styled-components";
import { Map} from 'google-maps-react';
import Arrow from "../Media/downArrow.svg"

export const ResPageStyle=styled.div`
                                display: flex;
                                width:100%;
                                gap: 30px;
                                flex-direction: column;
                                align-items: flex-start;
                                margin: 0;
                                padding: 0;
                                font-family: 'Poppins', sans-serif;
                                background-color: white;
                                padding-left: 8px;
                                @media only screen and (min-width: 796px){  
                                    display:grid;
                                    align-items: center;
                                    justify-content: center;
                                }`

export const RestPageContainerText=styled.div`        
                                @media only screen and (max-width: 796px){  
                                    width:100%
                                }`

export const RestPageContainerTextElements=styled.div`
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 18px;
                                line-height: 22px;
                                letter-spacing: 1.92px;
                                text-transform: uppercase;
                                color: #000000;
                                @media only screen and (min-width: 796px){  
                                    display:none;
                                }`

export const RestauranttPageContainer=styled.div`
                                display: flex;
                                flex-direction: column;
                                align-items: flex-start;
                                gap: 25px;
                                @media only screen and (min-width: 796px){  
                                    display: grid;
                                   grid-template-columns: auto auto auto;
                                }`

export const CardPageimg=styled.img`
                                width: 100%;
                                max-width: -webkit-fill-available;`

export const CardPagewrapper=styled.div`
                                background: #F9F4EA;
                                width:100%;`
                                
export const FilterElements=styled.div``

export const FilterElement=styled.ul`
                                display: flex;
                                flex-direction: row;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 21px;
                                list-style-type: none;
                                @media only screen and (min-width: 796px){  
                                    display:flex;
                                    align-items: center;
                                    justify-content: center;
                                }`

export const FilterElementText=styled.button`
                                background-color: #ffffff;
                                border:none;
                                font-size: 18px; 
                                font-weight: 400;
                                line-height: 21px;
                                color: #000000;
                                transition-duration: 0.2s;
                                width: max-content;
                                &:last-child{
                                    display:none;
                                }
                                &:focus{
                                    font-weight: bold;
                                    border-bottom: 1.8px solid rgba(222, 146, 0, 0.9);
                                }
                                &.Active{
                                    font-weight: bold;
                                    border-bottom: 1.8px solid rgba(222, 146, 0, 0.9);
                                }
                                @media only screen and (min-width: 796px){  
                                    &:last-child{
                                        display:flex;
                                    }
                                }`


type ChildrenProp = {
    children: React.ReactNode;
};
export const MapView=styled.div`
                                @media only screen and (min-width: 796px){  
                                    display:flex;
                                    justify-content: center;
                                    position: relative;
                                    width: 1000px;
                                    height: 550px;
                                }`

export const NoDataText=styled.div`
                                    visibility: visible;
                                    display: flex;
                                    font-size: 20px;
                                    padding-top: 100px;
                                    align-items: center;
                                    justify-content: center;
                                    width:360px;
                                    padding-left:20px;
                                    height:350px;
                                    font-weight: bold;
                                    @media only screen and (min-width: 796px){  
                                        visibility: visible;
                                        font-size: 27px;
                                        font-weight: bold;
                                        display: flex;
                                        padding-top: 100px;
                                        padding-bottom: 100px;
                                        align-items: center;
                                        width:600px;
                                        justify-content: center;
                                    }`

export const GoogleMap=styled(Map)<ChildrenProp>` 
                                @media only screen and (min-width: 796px){  
                                    display:flex;
                                }`

export const Filter=styled.div`
                                display:none;
                                @media only screen and (min-width: 796px){  
                                    width: 100%;
                                    height: 60px;
                                    left: 0px;
                                    margin-top:40px;
                                    background: #FAFAFA;
                                    display:flex;
                                    flex-direction:row;
                                    gap:47px;
                                    justify-content: center;
                                    align-items: center;
                                    margin-bottom: 30px;
                                }`

export const FilterText=styled.div`
                                border:none;
                                font-style: normal;
                                font-size: 16px;
                                line-height: 22px;
                                letter-spacing: 1.92px;
                                height: 22px;
                                background: #FAFAFA;
                                `

export const FilterContainer=styled.div`
                                display: flex;
                                flex-direction: row;
                                justify-content: center;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 8px;
                                height: 24px;`
                                  
export const PriceSlider=styled.div`
                                
                                width: 233px;`

export const DownArrow=styled.button`
                                border:none;
                                background-image: url(${Arrow});
                                background-size: cover;
                                width: 22px;
                                height: 12px;
                                background-color: #FAFAFA;
                                align-self: center;
                                cursor:pointer;`

interface DivProp{
        heigth:string,
        top:string,
}
export const PriceRangeContainer=styled.div<DivProp>`
                                position: absolute;
                                width: 353px;
                                margin-right: 18%;
                                display:flex;
                                justify-content: center;        
                                background: #FFFFFF;
                                box-shadow: 2px 4px 10px rgba(0, 0, 0, 0.25);
                                flex-direction:column;
                                align-items: center;
                                height: ${(p:DivProp)=>p.heigth};
                                margin-top: ${(p:DivProp) => p.top}; `

export const PriceRangeTitle=styled.h2`
                                width: auto;
                                height: 21px;
                                font-weight: 400;
                                font-size: 18px;
                                line-height: 21px;
                                letter-spacing: 1.92px;
                                margin: 0;`


export const PriceRangeTxt=styled.div`
                                font-weight: 200;
                                font-size: 14px;
                                line-height: 20px;
                                display: flex;
                                align-items: center;
                                letter-spacing: 1.97px;
                                color: #000000;
                                margin-top: 8px;`

export const CleanButton=styled.button`
                        background:none;
                        width: 112px;
                        height: 30px;
                        display: flex;
                        flex-direction: row;
                        justify-content: center;
                        align-items: center;
                        gap: 10px;
                        text-align: center;
                        letter-spacing: 2.67px;
                        font-size: 10px;
                        line-height: 20px;
                        text-transform: uppercase;
                        border: 1px solid #000000;`

export const CleanButton2=styled(CleanButton)`
                                margin-top: 13px;`

export const RatingContainer=styled.div`
                                display:flex;
                                flex-direction:column;
                                gap: 12px;
                                align-items: center;`

export const Rating=styled.div`
                                display:flex;
                                position: absolute;
                                margin-top: 155px;
                                padding-bottom:10px;
                                width: 300px;
                                height: 324px;
                                flex-direction: column;
                                align-items: center;
                                background: #FFFFFF;
                                box-shadow: 2px 4px 10px rgba(0, 0, 0, 0.25);
                                margin-left: 19%;
                                height: auto;
                                justify-content: space-around;
                        `


export const RateTitle=styled.h2`
                                width: auto;
                                height: 21px;
                                font-weight: 400;
                                font-size: 18px;
                                line-height: 21px;
                                letter-spacing: 1.92px;`

                                
export const DistanceFilter=styled.div<DivProp>`
                                display:flex;
                                position: absolute;
                                margin-top: ${(p:DivProp) => p.top}; 
                                width: 353px;
                                height: ${(p:DivProp)=>p.heigth};
                                flex-direction: column;
                                justify-content: center;
                                align-items: center;
                                background: #FFFFFF;
                                box-shadow: 2px 4px 10px rgba(0, 0, 0, 0.25);
                                justify-content: space-around;
                                `
export const FirstSection=styled.div`
                                display:flex;
                                flex-direction:row;
                                width: 272px;
                                justify-content: space-between;
                                font-weight: 300;
                                font-size: 14px;
                                line-height: 20px;
                                align-items: center;
                                letter-spacing: 1.97px;`

interface Props{
            color:string;
}
export const DistanseValue=styled.div<Props>`
                            font-size:14px;
                            color:${(p:Props)=>p.color};`