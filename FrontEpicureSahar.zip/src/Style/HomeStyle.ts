import styled from "styled-components";
export const HomeStyle=styled.div`
                                display: flex;
                                gap: 30px;
                                flex-direction: column;
                                align-items: flex-start;
                                margin: 0;
                                padding: 0;
                                background-color: white;
                                height: 100%;
                                @media only screen and (min-width: 796px){
                                    gap: 80px;
                                }`

export const Heroimage=styled.div`
                                width: 100%;
                                height: 273px;
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                flex-direction: column;
                                background-image: url(${(`../Media/Heroimg.svg`)});
                                background-size: cover;
                                @media only screen and (min-width: 796px){
                                    height: 550px;
                                }`

export const HeroTxt =styled.i`
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 24px;
                                align-self: center;
                                text-align: center;
                                line-height: 32px;
                                letter-spacing: 1.97px;
                                color: #000000;
                                display: flex;
                                width: 90%;
                                height: 55%;
                                gap:18px;
                                background: rgba(255, 255, 255, 0.88);
                                flex-direction: column;
                                justify-content: center;
                                @media only screen and (min-width: 796px){
                                    width: 500px;
                                    1440px;
                                    height: 150px;
                                }`