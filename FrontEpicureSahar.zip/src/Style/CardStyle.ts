import styled from "styled-components";
import { NavLink } from 'react-router-dom';

export const Cardwrapper=styled.div`
                                    background: #F9F4EA;`

export const Cardimg=styled.div``

export const Cardsimg=styled.img`
                            @media only screen and (min-width: 796px){  
                                width: 140%;
                                max-width: -webkit-fill-available;
                            }`

export const Cardcontent=styled.div`
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 200;
                                    font-size: 16px;
                                    line-height: 20px;
                                    letter-spacing: 1.97px;
                                    color: #000000;
                                    flex: none;
                                    order: 1;
                                    flex-grow: 0;
                                    display: flex;
                                    flex-direction: column;
                                    align-items: flex-start;
                                    gap: 10px;
                                    flex: none;
                                    order: 12;
                                    align-self: stretch;
                                    flex-grow: 0;
                                    @media only screen and (min-width: 796px){  
                                        display: flex;
                                        align-items: center;
                                        width: 379px;
                                        height: fit-content;
                                        padding-bottom:15px;
                                    }`


export const Name=styled.h3`
                                    display: block;
                                    font-size: 1.17em;
                                    margin-block-start: 0px;
                                    margin-block-end: 0px;
                                    margin-inline-start: 0px;
                                    margin-inline-end: 0px;
                                    font-weight: bold;`

export const All=styled(NavLink)`
                                display: flex;
                                flex-direction: row;
                                align-items: center;
                                align-content: baseline;
                                height: 24px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 400;
                                font-size: 16px;
                                line-height: 35px;
                                text-align: right;
                                letter-spacing: 2px;
                                text-transform: capitalize;
                                color: #000000;
                                flex: none;
                                order: 0;
                                flex-grow: 0;
                                text-decoration: none;
                                gap: 10px;
                                padding-left: 20px;
                                padding-top: 15px;
                                overflow:hidden;
                                @media only screen and (min-width: 796px){
                                    display: none;
                                }`