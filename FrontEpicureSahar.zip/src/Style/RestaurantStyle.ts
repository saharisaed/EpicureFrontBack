import { NavLink } from "react-router-dom";
import styled from "styled-components";


export const Cardchef=styled.div``

export const RestaurantContainer=styled.div`
                                width: 100%;`

export const RestContainerText=styled.i`
                                align-content: baseline;
                                height: 24px;
                                padding-left: 20px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 18px;
                                line-height: 24px;
                                letter-spacing: 1.25px;
                                text-transform: uppercase;
                                color: #000000;
                                @media only screen and (min-width: 796px){  
                                    display:flex;
                                    justify-content: center; 
                                    font-size: 30px;
                                }`

export const Restaurants=styled.div`
                                display: flex;
                                flex-direction: row;
                                flex-wrap: nowrap;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 24px;
                                width: auto; 
                                padding-left: 20px;
                                padding-top: 15px;
                                height: 25%;
                                overflow-x: scroll;
                                @media only screen and (min-width: 796px){  
                                    justify-content: center;
                                    overflow-x: hidden;
                                    height: 25%;
                                    display: flex;
                                    
                                }`

export const RestaurantsStars=styled.div`
                                display:none;
                                @media only screen and (min-width: 796px){  
                                    display:flex;
                                }`
                        

export const AllRestaurants=styled(NavLink)<{ border: string }>`
                                display: flex;
                                flex-direction: row;
                                align-items: center;
                                align-content: baseline;
                                height: 24px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 400;
                                font-size: 16px;
                                line-height: 35px;
                                text-align: right;
                                letter-spacing: 2px;
                                text-transform: capitalize;
                                color: #000000;
                                flex: none;
                                order: 0;
                                flex-grow: 0;
                                text-decoration: none;
                                gap: 10px;
                                padding-left: 20px;
                                padding-top: 15px;
                                overflow:hidden;
                                border-bottom:${(props)=>props.border};
                                @media only screen and (min-width: 796px){
                                    display: flex;
                                    justify-content: flex-end;
                                    padding-right: 20px;
                                    border-bottom:${(props)=>props.border};
                                }`