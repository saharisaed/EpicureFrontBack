import styled from "styled-components";

export const Chefwrapper=styled.div`
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            text-align: -webkit-center;
                            @media only screen and (min-width: 796px){
                                flex-direction: row;
                                width:80%;
                                gap:50px;
                            }`

export const Cheficon=styled.div`
                            display: flex;
                            flex-direction: column;
                            justify-content: flex-end;
                            width: 90%;
                            @media only screen and (min-width: 796px){
                                flex-direction: column;
                                dispaly:grid
                            }`

export const Chefcontent=styled.div``

export const Definition=styled.h1`
                            width: 90%;
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            padding-top: 15px;
                            font-size: 18px;
                            line-height: 28px;
                            text-align: justify;
                            letter-spacing: 1.25px;
                            color: #000000;
                            margin: 0px 0px 0px 0px;
                            @media only screen and (min-width: 796px){
                                width: 642px;
                                font-weight: 200;
                                font-size: 24px;
                                line-height: 35px;
                            }`


export const Chefname=styled.h3`
                            width: 93%;
                            height: 47px; 
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 400;
                            font-size: 18px;
                            line-height: 47px;
                            position: absolute;
                            text-align: center;
                            letter-spacing: 2.67px;
                            color: #000000;
                            background: rgba(255, 255, 255, 0.8);
                            flex: none;
                            order: 0;
                            align-self: stretch;
                            flex-grow: 0;   
                            margin-bottom: 0px;
                            @media only screen and (min-width: 796px){
                                display: table;
                                width: 33%;
                            }`

export const ChefContainerdiv=styled.div`
                            width: 100%;`
                           
                           
export const ChefContainerText=styled.div`
                            
                            height: 35px;
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 35px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;
                            padding-left: 20px;
                            padding-top: 15px;
                            @media only screen and (min-width: 796px){  
                                display:flex;
                                justify-content: center; 
                                font-size: 30px;
                            }`


                            
export const Chefs=styled.div`
                            display: flex;
                            flex-direction: row;
                            padding: 0px;
                            gap: 24px;
                            width: 100%;
                            height: auto;
                            padding-top: 15px;
                            overflow-x: scroll;
                            justify-content: center;
                            align-content: center;
                            @media only screen and (min-width: 796px){
                                flex-direction: row;
                                overflow-x: hidden;
                            }`