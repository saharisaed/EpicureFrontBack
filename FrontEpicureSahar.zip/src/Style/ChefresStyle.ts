import styled from "styled-components";

export const ChefRestaurantsContainer=styled.div`
                                width: 100%;
                                @media only screen and (min-width: 796px){
                                    padding-left:130px;
                                    margin:0px;
                                    width: fit-content;
                                    max-width:100%;
                                }`

export const CardChefReswrapper=styled.div`
                                background: #F9F4EA;
                                width: 245px;`

export const ChefRestaurantsContainerTxt=styled.i`
                                padding-left: 20px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 18px;
                                line-height: 35px;
                                letter-spacing: 1.25px;
                                text-transform: uppercase;
                                color: #000000;
                                @media only screen and (min-width: 796px){
                                    display:none;
                                }`

export const ChefRestaurants=styled.div`
                                display: flex;
                                flex-direction: row;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 24px;
                                width: auto;
                                height: 20%;
                                overflow-x: scroll;
                                font-family: 'Helvetica Neue';
                                padding-left: 20px;
                                padding-top: 15px;
                                @media only screen and (min-width: 796px){
                                    overflow-x: hidden;
                                    align-items:flex-start;
                                    display:flex;
                                    width: fit-content;

                                }`

export const CardChefRescontent=styled.div`
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 16px;
                                line-height: 20px;
                                letter-spacing: 1.97px;
                                color: #000000;
                                flex: none;
                                order: 1;
                                flex-grow: 0;
                                display: flex;
                                flex-direction: column;
                                align-items: flex-start;
                                gap: 10px;
                                flex: none;
                                order: 12;
                                align-self: stretch;
                                flex-grow: 0;
                                @media only screen and (min-width: 796px){  
                                    display: flex;
                                    align-items: center;
                                    height: fit-content;
                                    padding-bottom:15px;
                                }`

export const DesktopName=styled.h3`
                                    display: none;
                                    padding-left: 20px;
                                    font-family: 'Helvetica Neue';
                                    font-style: normal;
                                    font-weight: 200;
                                    font-size: 18px;
                                    line-height: 35px;
                                    letter-spacing: 1.25px;
                                    text-transform: uppercase;
                                    color: #000000;
                                    @media only screen and (min-width: 796px){
                                        display:flex;
                                        width: fit-content;
                                        margin:0;
                                        font-family: 'Helvetica Neue';
                                        font-style: normal;
                                        font-weight: 200;
                                        margin: 0;
                                        font-size: 30px;
                                        line-height: 35px;
                                    }`