import { FilterWords } from "../Types/FilterWords";
import IRestaurants from "../Types/restaurantsTypes/IRestaurants";

export function GetPopularRestaurants(restaurantsAll:IRestaurants[]){
    let restaurantsList:IRestaurants[];
    restaurantsList=[];
    if(restaurantsAll!=null){
        restaurantsList=restaurantsAll.slice().sort((a, b) =>
        a.stars > b.stars ? -1 : 1,
        )
    }
    return restaurantsList;
}

export function GetNewRestaurants(restaurantsAll:IRestaurants[]){
    let restaurantsList:IRestaurants[];
    restaurantsList=[];
    if(restaurantsAll!=null){
        restaurantsList=restaurantsAll.slice().sort((a, b) =>
        a.establishYear > b.establishYear ? -1 : 1,
        )
    }
    return restaurantsList;
}

export function GetRestaurantsByFeature(featureName:string,restaurantsAll:IRestaurants[]) {
    let restaurantsList:IRestaurants[];
    if(featureName===FilterWords.ALL)
        return restaurantsAll;
    if(featureName===FilterWords.NEW){
        return GetNewRestaurants(restaurantsAll);
    }
    if(featureName===FilterWords.OPENED){
        let today = new Date();
        restaurantsList=[];
        restaurantsAll.map(element=> element.openingHours.forEach(function (item) {  
            if(item.day===today.getDay()&&item.open<=today.getHours()&&item.close>=today.getHours()){
                restaurantsList.push(element);  
            }
        }));
        return restaurantsList;
    }
    if(featureName===FilterWords.POPULAR){
        return GetPopularRestaurants(restaurantsAll);
    }
    return restaurantsAll;   
}

export default GetRestaurantsByFeature;