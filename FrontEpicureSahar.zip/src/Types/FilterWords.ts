export enum FilterWords {
    ALL="All",
    NEW="New",
    POPULAR="Most Popular",
    OPENED="Open Now",
    Map="Map",
    PriceRange="priceRange"
}


