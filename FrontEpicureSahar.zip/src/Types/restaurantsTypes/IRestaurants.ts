import IDishs from "../DishsTypes/IDishs"

interface Itime{
    day:number,
    open:number,
    close:number
}

interface IRestaurants{
    name:string
    establishYear:number
    chef:string
    openingHours:Array<Itime>
    dishs:Array<IDishs>
    resturantPicture:string
    featureName:string
    stars:Number
    resturantLocationLat:string
    resturantLocationLng:string
    priceavg:number
}


export default IRestaurants;