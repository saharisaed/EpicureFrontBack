import res from "../restaurantsTypes/restaurants";

export interface IChefs{
    name:string;
    description:string;
    chefsRestaurants:Array<res>;
    chefPicture:string;
}

export default IChefs