interface IDishs{
    name:string;
    description:string;
    restaurant:string;
    type:string;
    category:string;
    dishPicture:string;
    categoryIcon:string;
    price:number;
}

export default IDishs;