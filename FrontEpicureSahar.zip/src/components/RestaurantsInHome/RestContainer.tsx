import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { GetPopularRestaurants } from '../../helperFunc/resByFeature';
import { State } from '../../state';
import { AllRestaurants, RestaurantContainer, Restaurants, RestContainerText } from '../../Style/RestaurantStyle';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import RestaurantsCard from './RestaurantsCard';


const RestContainer=() =>{
  const restaurantsAll=useSelector((state :State) => state.allRestaurants);
  const [restaurantsList,setRestaurantsList] =useState<IRestaurants[]>([]);
  const[clicked,setClicked]=useState(false);
  const showBorder="1.8px solid rgba(222, 146, 0, 0.9)";
  const [width,setWidth]=useState(document.documentElement.clientWidth);
  const resizeHandler=()=>{
    setWidth(window.innerWidth)
  }
  const handleHideHamb2=()=>{
    setClicked(true);
    const a=document.getElementById('HambrestaurantsElement');
    
      if(a) a.style.borderBottom=showBorder;
  
  }
  useEffect(() => {
    window.addEventListener("resize",resizeHandler);
    setRestaurantsList(GetPopularRestaurants(restaurantsAll.restaurantsList));
 
  }, [restaurantsAll.restaurantsList]);
    return(
            <RestaurantContainer >
                <RestContainerText>
                    popular restaurant in epicure:
                </RestContainerText>
            <Restaurants >
                  {(width>796)?restaurantsList.slice(0,3).map((restaurant:IRestaurants, index)=><RestaurantsCard restaurant={restaurant} key={index}/>)
                  :restaurantsList.map((restaurant:IRestaurants, index)=><RestaurantsCard restaurant={restaurant} key={index}/>)}
            </Restaurants>
            <AllRestaurants to={'Restaurants'}onClick={handleHideHamb2} border={(clicked)?showBorder:"none"} >All restaurants<img src={require('../../Media/Icons/allres_icon.png')} alt={"all restaurants"}/></AllRestaurants>
            </RestaurantContainer>
    )
}


export default RestContainer;