import {  Cardcontent, Cardimg, Cardsimg, Cardwrapper,Name } from '../../Style/CardStyle';
import {Cardchef, RestaurantsStars} from '../../Style/RestaurantStyle';
import res from '../../Types/restaurantsTypes/restaurants';
import ReactStars from 'react-stars'
import React from 'react'

const RestaurantsCard:React.FC<res> = ({ 
    restaurant
})=>{
    return (
      <Cardwrapper>
        <Cardimg>
          <Cardsimg src={restaurant.resturantPicture}/>
        </Cardimg>
        <Cardcontent>
          <Name>{restaurant.name}</Name>
          <Cardchef>{restaurant.chef}</Cardchef>
          <RestaurantsStars>
          <ReactStars count={5} value={parseInt(restaurant.stars.toString())} edit={false} color2={"#DE9200"} size={30}/>
          </RestaurantsStars>
        </Cardcontent>
      </Cardwrapper>
    );
}






export default RestaurantsCard;