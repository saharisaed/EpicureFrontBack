import { useState } from 'react';
import { HambElement, HambElementLink, HambelementsText } from '../Style/HamburgerStyle';

const Hamburger=() =>{
  const[restaurantsClicked,setrestaurantsClicked]=useState(false);
  const[chefssClicked,setchefsClicked]=useState(false);
  const showBorder="1.8px solid rgba(222, 146, 0, 0.9)";

  const handleHideHamb=()=>{
    setrestaurantsClicked(true);
    setchefsClicked(false);
    const a=document.getElementById("CloseIcon"); 
    if(a) a.click(); 
  }

  const handleHideHamb2=()=>{
    setchefsClicked(true);
    setrestaurantsClicked(false);
    const a=document.getElementById("CloseIcon"); 
    if(a) a.click(); 
  }

    return (
        <HambelementsText id='HambelementsText'> 
            <HambElement>
              <HambElementLink id='HambrestaurantsElement' to="/Restaurants" border={(restaurantsClicked)?showBorder:"none"} onClick={handleHideHamb}>Restaurants</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink id='HambChefsElement' to="/Chefs" border={(chefssClicked)?showBorder:"none"} onClick={handleHideHamb2}>Chefs</HambElementLink>
            </HambElement>
            <br></br>
            <HambElement>
              <HambElementLink border={(chefssClicked)?showBorder:"none"}  to="/contact" onClick={handleHideHamb2}>Contact Us</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink border={(chefssClicked)?showBorder:"none"}  to="/Term" onClick={handleHideHamb2}>Term of Use</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink border={(chefssClicked)?showBorder:"none"} to="/policy" onClick={handleHideHamb2}>Privacy Policy</HambElementLink>
            </HambElement>
          </HambelementsText>
    );

}

export default Hamburger;