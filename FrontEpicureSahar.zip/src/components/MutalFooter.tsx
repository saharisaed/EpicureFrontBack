import { Mutalfooter, MutalfooterLink } from "../Style/FooterStyle"

const MutalFooter=()=>{
    return(
        <Mutalfooter>
           <MutalfooterLink to="/contact">Contact Us</MutalfooterLink> 
           <MutalfooterLink to="/about">Term of Use</MutalfooterLink>  
           <MutalfooterLink to="/policy">Privacy Policy</MutalfooterLink> 
        </Mutalfooter>
    )
}

export default MutalFooter