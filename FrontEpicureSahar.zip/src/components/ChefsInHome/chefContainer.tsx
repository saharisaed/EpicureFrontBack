import { useSelector } from 'react-redux';
import { State } from '../../state';
import { ChefContainerdiv, ChefContainerText, Chefs } from '../../Style/ChefStyle';
import IChefs from '../../Types/chefType/IChefs';
import ChefCard from './chefCard';

const ChefContainer=() =>{
    const chefsAll=useSelector((state :State) => state.allChefs);
    return(
        <ChefContainerdiv>
            <ChefContainerText>
                  Chef of the week:
            </ChefContainerText>
        <Chefs>
            {
                chefsAll.chefsList.map((chef:IChefs, index)=><ChefCard chef={chef} key={index}/>)
            }
      
        </Chefs>
        </ChefContainerdiv>
 
    )
}


export default ChefContainer;

