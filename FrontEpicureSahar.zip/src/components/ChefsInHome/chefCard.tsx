import { Chefcontent, Cheficon, Chefname, Chefwrapper, Definition } from '../../Style/ChefStyle';
import dish from '../../Types/chefType/chefs';

const ChefCard:React.FC<dish> = ({ 
    chef
})=>{
    return (
      <Chefwrapper>
        <Cheficon>
          <img src={chef.chefPicture} alt="chef"/> 
          <Chefname>{chef.name}</Chefname>
        </Cheficon>
        <Chefcontent>
          <Definition>{chef.description}</Definition>
        </Chefcontent>
        </Chefwrapper>
    );
}






export default ChefCard;