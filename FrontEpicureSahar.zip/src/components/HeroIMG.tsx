import Search from '../PopUps/search';
import { Heroimage, HeroTxt } from '../Style/HomeStyle'

const Heroimg=() =>{
    return (
        <Heroimage >
            <HeroTxt>
                Epicure works with the top
                chef restaurants in Tel Aviv
                <Search/>
            </HeroTxt>
        </Heroimage>
    );
}

export default Heroimg;