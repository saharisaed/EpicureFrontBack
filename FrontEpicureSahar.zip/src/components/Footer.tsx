import { Footercontent, Footerimg, Footerimges, Footerlogoimg, FooterStyle, Footertitle } from "../Style/FooterStyle";



const Footer=()=>{
    return(
        <FooterStyle>
            <Footerlogoimg src={('../Media/logo.svg')} /> 
            <Footerimges>
                <Footerimg src={('../Media/googleplay.svg')} /> 
                <Footerimg src={('../Media/appstore.svg')} /> 
            </Footerimges>
            <Footertitle>about us:</Footertitle>
            <Footercontent>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In a lacus vel justo fermentum bibendum non 
                eu ipsum. Cras porta malesuada eros, eget blandit
                turpis suscipit at.  Vestibulum sed massa in magna sodales porta.  Vivamus elit urna, 
                dignissim a vestibulum.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In a lacus vel justo fermentum bibendum no
                eu ipsum. Cras porta malesuada eros.
            </Footercontent>
        </FooterStyle>

    );

}


export default Footer;