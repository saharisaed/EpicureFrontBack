import { Cardimg, Name } from '../../Style/CardStyle';
import { CardChefRescontent, CardChefReswrapper } from '../../Style/ChefresStyle';
import res from '../../Types/restaurantsTypes/restaurants';

const ChefRestaurantsCard:React.FC<res> = ({ 
    restaurant
})=>{

      return (
      <CardChefReswrapper>
        <Cardimg>
          <img src={restaurant.resturantPicture} alt={"resturant"}/>
        </Cardimg>
        <CardChefRescontent>
          <Name>{restaurant.name}</Name>
        </CardChefRescontent>
      </CardChefReswrapper>
    );
}



export default ChefRestaurantsCard;