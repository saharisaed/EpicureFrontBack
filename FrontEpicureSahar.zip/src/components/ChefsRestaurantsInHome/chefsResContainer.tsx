import { Key } from 'react';
import { useSelector } from 'react-redux';
import { State } from '../../state';
import { All } from '../../Style/CardStyle';
import { ChefRestaurants, ChefRestaurantsContainer, ChefRestaurantsContainerTxt, DesktopName } from '../../Style/ChefresStyle';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import ChefRestaurantsCard from './chefsResCard';

const ChefResContainer=() =>{
    const chefsAll=useSelector((state :State) => state.allChefs);
    let chefName: string,chefFirstName:string;
    chefName='';
    chefFirstName='';
    if(chefsAll.chefsList[0]!==undefined){
      chefName=chefsAll.chefsList[0].name;
    }
    
    if(chefName!==null && chefName!==undefined){
      chefFirstName=chefName.split(" ")[0];
    }

    const restaurantsAll=useSelector((state :State) => state.allRestaurants);
    let restaurants:any = restaurantsAll.restaurantsList.filter( function (restaurant) {
          return restaurant.chef === chefName;
    });

        return (
            <ChefRestaurantsContainer>
              <ChefRestaurantsContainerTxt>
                    Chef of the week:
              </ChefRestaurantsContainerTxt>
              <DesktopName>{chefFirstName}'s Restaurants</DesktopName>
            <ChefRestaurants>
            {
                restaurants.map((restaurant:IRestaurants, index: Key | null | undefined)=><ChefRestaurantsCard restaurant={restaurant} key={index}/>)
            }
            </ChefRestaurants>
                 <All to="Restaurants">All restaurants<img src={require('../../Media/Icons/allres_icon.png')} alt="all restaurants for the chef" /></All>
            </ChefRestaurantsContainer>
          );
}


export default ChefResContainer;