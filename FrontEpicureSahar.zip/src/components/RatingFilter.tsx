import ReactStars from "react-stars"
import { RateTitle, Rating, RatingContainer } from "../Style/RestaurantsPageStyle"

const RatingFilter=()=>{
            return(
                <Rating>
                     <RateTitle>Rating</RateTitle>
                    <RatingContainer>
                        <ReactStars
                        count={5}
                        value={0}
                        color2={"#DE9200"} size={30}/>
                    </RatingContainer>
                </Rating>
            )

}



export default RatingFilter