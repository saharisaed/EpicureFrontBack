import React, { useEffect, useState } from "react";
import Slider from '@material-ui/core/Slider';
import { CleanButton2, PriceRangeContainer, PriceRangeTitle, PriceRangeTxt, PriceSlider } from "../Style/RestaurantsPageStyle";
import { useDispatch, useSelector } from "react-redux";
import { State } from "../state";
import { setPriceRange } from "../state/reducer/priceFilter";

const PriceRange=()=>{
    const [value, setValue] =  React.useState([12,357]);
    const [showBotton,setShowBotton]=useState(false);
    const dispatch=useDispatch();
    const priceFilter=useSelector((state :State) => state.priceFilter);
    const[min,setMin]=useState(priceFilter.min);
    const[max,setMax]=useState(priceFilter.max);
  
    const rangeSelector = (event: any, newValue: any) => {
        setValue(newValue);
        setMin(value[0]);
        setMax(value[1]);

      }
      
      useEffect(()=>{
          (min>12 || max<357)?setShowBotton(true):setShowBotton(false);
          dispatch(setPriceRange({min,max}))
      },[min,max])
     
      return(
        <PriceRangeContainer heigth={ showBotton?"197px":"162px" } top={ showBotton?"259px":"225px" }>
          <PriceRangeTitle>Price Range Selected</PriceRangeTitle>
              <PriceRangeTxt>&#8362;{12}-&#8362;{357}</PriceRangeTxt>
          <PriceSlider >
            <Slider 
            style={{ color: "black" }}
            value={value}
            onChange={rangeSelector}
            onChangeCommitted={rangeSelector}
            valueLabelDisplay="auto"
            min={12} max={357} 
            />
          </PriceSlider>
          {showBotton&&<CleanButton2 onClick={() => {setValue([12,357]);setMax(357);setMin(12);window.location.replace("http://localhost:3000/Restaurants");} }>clear</CleanButton2> }
        </PriceRangeContainer>
      )
}




export default PriceRange