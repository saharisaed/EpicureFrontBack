import { DesktopTitle, DishType, Signaturediv, Signatureimgs,  Title } from "../Style/SignatureStyle";


const Signature=()=>{

    return(
        <Signaturediv>
            <Title>Signature Dish Of:</Title>
            <DesktopTitle>THE MEANING OF OUR ICONS:</DesktopTitle>
                <Signatureimgs src={('./Media/icons/spicy_icon2.svg')} />
                <DishType>Spicy</DishType>
                <Signatureimgs src={('./Media/icons/vegitarian_icon.svg')} />
                <DishType>Vegitarian</DishType>
                <Signatureimgs src={('./Media/icons/vegan_icon.svg')} />
                <DishType>Vegan</DishType>
        </Signaturediv>
    )

}

export default Signature; 