import { ReactComponent as Brand } from '../Media/logo.svg'
import NavbarAssest from '../assest/NavbarAssest'
import Hambassest from '../assest/Hambassest'
import { DesktopLogo, HomeLink, Logo, NavbarStyle } from '../Style/NavbarStyle'
import  { ReactComponent as DesktopBrand}  from '../Media/desktoplogo.svg'
import Hamburger from './Hamburger'
import { DesktopHamb } from '../Style/HamburgerStyle'


const Navbar = () => {

  const handleClick = ()=>{
    window.location.replace("http://localhost:3000/");
  }
  
  return (
    <NavbarStyle id='Navbar'>
        <Hambassest/>
        <Logo>
          {
            <HomeLink to={"/"}> <Brand /> </HomeLink>
          } 
           <DesktopLogo> 
            {
              <HomeLink to={"/"} onClick={handleClick} > <DesktopBrand/> </HomeLink>
            } 
            </DesktopLogo>
            <DesktopHamb> 
              <Hamburger/> 
            </DesktopHamb>
          </Logo>

       
        
        <NavbarAssest/>
     
    </NavbarStyle>
  )
}

export default Navbar