import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { State } from '../../state';
import { All } from '../../Style/CardStyle';
import { DishContainerText, Dishs, DishsContainer } from '../../Style/DishsStyle';
import IDishs from '../../Types/DishsTypes/IDishs';
import DishsCard from './DishsCard';

const DishContainer=() =>{
    const dishsAll=useSelector((state :State) => state.allDishs);
    const [dishsList,setDishsList] =useState<IDishs[]>([]);
    const [width,setWidth]=useState(document.documentElement.clientWidth);
    const resizeHandler=()=>{
      setWidth(window.innerWidth)
    }
    useEffect(() => {
        window.addEventListener("resize",resizeHandler)
        setDishsList(dishsAll.dishsList);
      },[dishsAll.dishsList]);

    return(
        <DishsContainer>
            <DishContainerText>
                popular Dishs in epicure:
            </DishContainerText>
        <Dishs>
            {(width>796)?dishsList.slice(0,3).map((dish:IDishs, index)=><DishsCard dish={dish} key={index}/>):
            dishsList.map((dish:IDishs, index)=><DishsCard dish={dish} key={index}/>)}
        </Dishs>
        <All to="/blog">All dishs<img src={require('../../Media/Icons/allres_icon.png')} alt="all Dishs"/></All>
        </DishsContainer>
    )
}


export default DishContainer;