import { Cardcontent, Cardimg, Cardsimg, Cardwrapper, Name } from '../../Style/CardStyle';
import { DishIcon, Ingredients, Price, Priceimg} from '../../Style/DishsStyle';
import dish from '../../Types/DishsTypes/Dishes';

const DishsCard:React.FC<dish> = ({ 
    dish
})=>{
    return (
      <Cardwrapper>
        <Cardimg>
          <Cardsimg src={dish.dishPicture} />
        </Cardimg>
        <Cardcontent>
          <Name>{dish.name}</Name>
          <Ingredients>{dish.description}</Ingredients>
          <DishIcon> <img src={dish.categoryIcon} alt={"categoryIcon"}/></DishIcon>
          <Price>{<Priceimg src={"./Media/icons/ils_icon.svg"}/>}{dish.price}</Price>
        </Cardcontent>
        </Cardwrapper>
    );
}






export default DishsCard;