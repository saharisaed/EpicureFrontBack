import { Slider } from "@material-ui/core"
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { setDistance } from "../state/reducer/distanceRestaurant";
import { CleanButton2, DistanceFilter, DistanseValue, FirstSection, PriceRangeTitle, PriceSlider } from "../Style/RestaurantsPageStyle";


const Distance=()=>{
    const [value, setValue] =  React.useState([12,357]);
    const[value1]=useState(0);
    const dispatch=useDispatch();
    const [showBotton,setShowBotton]=useState(false);
    
    useEffect(()=>{
        dispatch(setDistance(value1));
    },[value1])

    const rangeSelector = (event: any, newValue: any) => {
        setValue(newValue);
    }
        return(
            <DistanceFilter heigth={ value1>0?"167px":"137px"} top={ value1>0?"220px":"205px " }>
                <PriceRangeTitle>Distance</PriceRangeTitle>
                <PriceSlider>
                <FirstSection>
                    <DistanseValue color="black" >My location</DistanseValue>
                </FirstSection>
                <Slider 
                    style={{ color: "black" }}
                    value={value}
                    onChange={rangeSelector}
                    onChangeCommitted={rangeSelector}
                    valueLabelDisplay="auto"
                    min={12} max={357} 
                    />
                {showBotton&&<CleanButton2 onClick={() => {window.location.replace("http://localhost:3000/Restaurants");} }>clear</CleanButton2> }
                </PriceSlider>
            </DistanceFilter>
        )
}


export default Distance