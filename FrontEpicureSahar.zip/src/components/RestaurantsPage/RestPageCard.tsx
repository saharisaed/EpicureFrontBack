import ReactStars from 'react-stars';
import { Cardcontent, Cardimg, Name } from '../../Style/CardStyle';
import { CardPageimg, CardPagewrapper } from '../../Style/RestaurantsPageStyle';
import { Cardchef, RestaurantsStars } from '../../Style/RestaurantStyle';
import res from '../../Types/restaurantsTypes/restaurants';

const RestaurantsPageCard:React.FC<res> = ({ 
    restaurant
})=>{
    return (
      <CardPagewrapper>
        <Cardimg>
          <CardPageimg src={restaurant.resturantPicture}/>
        </Cardimg>
        <Cardcontent>
          <Name>{restaurant.name}</Name>
          <Cardchef>{restaurant.chef}</Cardchef>
          <RestaurantsStars>
            <ReactStars count={5} value={parseInt(restaurant.stars.toString())} edit={false} color2={"#DE9200"} size={30}/>
          </RestaurantsStars>
        </Cardcontent>
        </CardPagewrapper>
    );
}


export default RestaurantsPageCard;