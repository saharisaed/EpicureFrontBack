import { useSelector } from 'react-redux';
import RestPageAssest from '../../assest/restPageMainFilters';
import { State } from '../../state';
import {NoDataText, RestauranttPageContainer, RestPageContainerText, RestPageContainerTextElements } from '../../Style/RestaurantsPageStyle';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import RestPageCard from './RestPageCard';
import { useEffect, useState } from 'react';
import GetRestaurantsByFeature from '../../helperFunc/resByFeature';
import { FilterWords } from '../../Types/FilterWords';
import GoogleMapComponent  from '../MapView';
import RestPageSecondFilters from '../../assest/restPageSecondFilters';


const RestPageContainer=() =>{
    const restaurantsAll=useSelector((state :State) => state.allRestaurants);
    const filterChoise =useSelector((state :State) => state.filter)
    const priceFilter=useSelector((state :State) => state.priceFilter);
    const [restaurantsList,setRestaurantsList] =useState<IRestaurants[]>([])
    const [isMapview,setisMapview]=useState(false)

    useEffect(() => {
        setRestaurantsList(GetRestaurantsByFeature(filterChoise,restaurantsAll.restaurantsList));
        if(filterChoise===FilterWords.Map) setisMapview(true)
        else setisMapview(false)
    }, [filterChoise,restaurantsAll.restaurantsList]);
    console.log(filterChoise)
    return(
        <RestPageContainerText>
            <RestPageContainerTextElements>
                Restaurants
            </RestPageContainerTextElements>
            <RestPageAssest/>
            <RestPageSecondFilters/>
            <RestauranttPageContainer  id='RestPageContainer' >
                 {(isMapview)&&<GoogleMapComponent restaurants={restaurantsAll.restaurantsList}/>}
                {(!isMapview)&&(restaurantsList===null||restaurantsList.length===0)&&<NoDataText> There is no suitable data</NoDataText>}
                {(!isMapview)&&restaurantsList.map((restaurant:IRestaurants, index)=><RestPageCard restaurant={restaurant} key={index}/>)}
            </RestauranttPageContainer>
        </RestPageContainerText>
    )
}


export default RestPageContainer;

