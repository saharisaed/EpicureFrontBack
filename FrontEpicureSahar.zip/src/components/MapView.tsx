import  { Component } from 'react';
import { Marker, GoogleApiWrapper } from 'google-maps-react';
import { GoogleMap, MapView } from '../Style/RestaurantsPageStyle';
import IRestaurants from '../Types/restaurantsTypes/IRestaurants';


export  class GoogleMapComponent extends Component<any, any,{restaurants:any[]}> {
  state: any=[];
   constructor(props:any) {
    super(props);
    this.state = {
     currentLatLng: {
            lat: 0,
            lng: 0
      }
    }
  }

  drawMarker = () => {
    if(this.props.restaurants!==null){
    return this.props.restaurants.map((store: IRestaurants,i:any) => {
      if(store.resturantLocationLng!==undefined&&store.resturantLocationLat!==undefined){
      return <Marker key={i}  position={{
       lat: parseFloat(store.resturantLocationLat),
       lng: parseFloat(store.resturantLocationLng)
     }}   icon={{  url: 'https://epicurepics.s3.ap-northeast-1.amazonaws.com/restaurantPinMap.png' ,scaledSize: new google.maps.Size(50,50)}}
     onClick={() => console.log("Event Hanlder Called")} />
    
    }else return null;})}
  }
  showCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        position => {
          this.setState(({
            currentLatLng: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            },
            restaurants:this.state.allRestaurants
          }))
        }
      )
    }
  }
  componentDidMount() {
    this.showCurrentLocation()
  
  }
 
  render() {
   
    console.log(this.state.currentLatLng.lat)
    return (
        <MapView id='MapView' >
        <GoogleMap 
          google={this.props.google}
          zoom={8}
          initialCenter={{ 
            lat: 32.046051, lng: 34.851612
        }}>
          {this.drawMarker()}
        <Marker 
            position={{ lat: this.state.currentLatLng.lat, lng: this.state.currentLatLng.lng }}
            icon={{  url: 'https://epicurepics.s3.ap-northeast-1.amazonaws.com/HomePinMap.png' ,scaledSize: new google.maps.Size(50,50)}}
        />
        </GoogleMap>
        </MapView>
          
        
    );
  }
}

export default GoogleApiWrapper({
  apiKey: 'AIzaSyCfRw77ml0HCaXKGkbvhThguLvjCyi3nSo'
})(GoogleMapComponent);