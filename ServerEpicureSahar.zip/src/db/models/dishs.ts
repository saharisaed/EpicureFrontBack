import mongoose from "mongoose";

const dishsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    restaurant: {
      type: String,
      required: false,
    },
    type: {
      type: String,
      required: false,
    },
    price: {
      type: Number,
      required: false,
    },
    dishPicture: {
      type: String,
      required: false,
    },
    category: {
        type: String,
        required: false,
    },
    categoryIcon: {
      type: String,
      required: false,
  },
  },
  { timestamps: true }
);

const dishs = mongoose.model("Dishs", dishsSchema);

export default dishs;
