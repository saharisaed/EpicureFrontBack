import mongoose from "mongoose";

const restaurantsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    establishYear: {
      type: Number,
      required: true,
    },
    chef: {
      type: String,
      required: true,
    },
    openingHours: {
      type: Array,
      required: true,
    },
    dishs: {
      type: Array,
    },
    resturantPicture: {
      type: String,
      required: true,
    },
    featureName:{
      type:String
    },
    stars:{
      type:Number
    },
    resturantLocationLat: {
      type: String,
    },
    resturantLocationLng: {
      type: String,
    },
    priceAvg:{
      type:Number
    }
  },
  { timestamps: true }
);

const Restaurants = mongoose.model("Restaurants", restaurantsSchema);

export default Restaurants;
