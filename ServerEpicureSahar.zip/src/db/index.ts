import mongoose from "mongoose";

const connectDb = async () => {
  mongoose.set("strictQuery", true);
  await mongoose.connect("mongodb+srv://sahar:sahar@cluster0.5oilmal.mongodb.net/?retryWrites=true&w=majority");
};

export { connectDb };