import { Router } from "express";
import { DishsController } from "../controllers/dishsController";

const router = Router();

router.get("/getDishs", DishsController.getDishs);
router.post("/createDish", DishsController.createDish);

export default router;
