import Dishs from "../db/models/dishs";
import Restaurants from "../db/models/restaurants";

export class DishsDal {
  public async createDish(dish: any) {
    dish = new Dishs({
      name: dish.name,
      description: dish.description,
      restaurant: dish.restaurant,
      type:dish.type,
      price:dish.price,
      category:dish.category,
      dishPicture:dish.dishPicture,
      categoryIcon:dish.categoryIcon,
    });

  
    const response = await Dishs.create(dish);
    const result = await Restaurants.findOne({ name: response.restaurant }).updateOne({
      $push: { dishs: response._id },
    });
    return response;
  }
  
  public findAll() {
    return Dishs.find();
  }
}

